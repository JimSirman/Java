import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

//class that makes the board
public class Board {
	
	private ArrayList<String [][]> savedList;
	private String[][] brd;
	private int num = 0;	
	
	//constructor to make the board
	public Board() {
		this.brd = new String [10][10];
		this.savedList = new ArrayList<String[][]>(100);
		this.setNum(getNum() + 1);
	}
	
	//adds the board to the arrayList
	public void setBoardState(int num, String[][] b){
		String[][] bd = new String[10][10];
		for(int i = 0; i < 10; i++){
			for(int j = 0; j < 10; j++){
				bd[i][j] = b[i][j]; 
			}
		}
		savedList.add(num, bd);	
	}
	
	//returns the board with the specified value
	public String getSaveState(int num) {
		//System.out.println(Arrays.deepToString(savedList.get(num)));
		return Arrays.deepToString(savedList.get(num));
	}

	public int getNumBoards() {
		int size = savedList.size();
		return size;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}	
	
	
}
