import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class TicTacToe{
	
	static String match = " ";
	public static int r = 0;
	public static int c = 0;
	public static boolean xWins = false, oWins = false, draw = false;;
	public static String mark = " ";
	public static Scanner scanner = new Scanner(System.in);	

	//main method	
	public static void main(String[] args){
		String[][] board = new String [10][10]; 
		//create an object to save the board states
		Board Board = new Board();

		//clear the board
		clearBoard(board);
		
		//loop until game is won/lost/draw
		do {
			//prompt user for an X or an O
			do{	
				System.out.println("What would you like to mark: X or O?");
				String input = scanner.next();
				mark = input.toUpperCase();
				if(mark.equalsIgnoreCase("X") || mark.equalsIgnoreCase("O")){
					break;
				}
				else{
					System.out.println("Your mark must be an X or an O");
					System.out.println("Error on: " + mark);
					System.out.println();
				}

			}while((!mark.equalsIgnoreCase("X")) && !mark.equalsIgnoreCase("O"));				
			do {			
				//Prompt user for row 
				do{
					System.out.println("What row would you like to mark: [0 --> 9]");
					r = scanner.nextInt();
					if(r < 0 || r > 9){
						System.out.println("Your ROW must be between [0 --> 9]");
						System.out.println();
					}
				}while(r < 0 || r > 9);	

				//prompt user for column
				do{
					System.out.println("What column would you like to mark: [0 --> 9]");
					c = scanner.nextInt();
					if(c < 0 || c > 9){
						System.out.println("Your COLUMN must be between [0 --> 9]");
						System.out.println();
					}
				}while(c < 0 || c > 9);

				if(board[r][c].equalsIgnoreCase("X") ||  board[r][c].equalsIgnoreCase("O")) {
					System.out.println("Error: There is already a marker at [" + r + "]" + "[" + c + "]");
					System.out.println();					
				}
				else {
					board[r][c] = mark;
				}
			}while( board[r][c] == "X" ||  board[r][c] == "O" );

			//save the state of the board
			Board.setBoardState(0, board);

			//get the saved state
			printBoard(Board.getSaveState((0)));

		}while(checkWin(twoDm(Board.getSaveState(0))) == false || checkDraw(twoDm(Board.getSaveState(0))) == false);

		if(xWins == true){
			System.out.println("X wins the game");
		}
		else if(oWins == true){
			System.out.println("O wins the game");
		}
		else if(checkDraw(twoDm(Board.getSaveState(0))) == true){
			System.out.println("Its a draw!");
		}		
	}//end main
	//check the board for a win or a draw	
	public static boolean checkWin(String[][] brd){
		//strings to check win against
		String myString = " ", tmpString1 = "XXXXX", tmpString2 = "OOOOO";

		//when win is true, game ova hova!!!!
		boolean win = false;

		//check the board for win in the right direction
		for(int i = 0; i < 10; i++){
			if(win == true){
				break;
			}
			else{
				for(int j = 0; j < 6; j++){
					myString = scanR(i, j, 5, myString, brd);
					//System.out.println("myString is " + myString);
					if(tmpString1.equals(myString.trim())){

						win = true;
						xWins = true;
						break;
					}
					else if(tmpString2.equals(myString.trim())){
						oWins = true;
						win = true;
						break;
					}
				}//end inner for loop
			}//end outer else
		}//end check in right direction


		//check the board for win in the right and down direction
		for(int i = 0; i < 6; i++){
			if(win == true){
				break;
			}
			else{
				for(int j = 0; j < 6; j++){
					myString = scanRD(i, j, 5, myString, brd);
					if(tmpString1.equals(myString.trim())){
						xWins = true;
						win = true;
						break;
					}
					else if(tmpString2.equals(myString.trim())){
						oWins = true;
						win = true;
						break;
					}
				}//end inner for loop
			}//end outer else
		}//end check right and down	

		//check the board for win in the down direction
		for(int i = 0; i < 6; i++){
			if(win == true){
				break;
			}
			else{
				for(int j = 0; j < 10; j++){
					myString = scanD(i, j, 5, myString, brd);
					//System.out.println("myString is " + myString);
					if(tmpString1.equals(myString.trim())){
						xWins = true;
						win = true;
						break;
					}
					else if(tmpString2.equals(myString.trim())){
						oWins = true;
						win = true;
						break;
					}
				}//end inner for loop
			}//end outer else
		}//end check down

		//check the board for win in the left and down direction
		for(int i = 0; i < 6; i++){
			if(win == true){
				break;
			}
			else{
				for(int j = 9; j > 3; j--){
					myString = scanLD(i, j, 5, myString, brd);
					if(tmpString1.equals(myString.trim())){
						xWins = true;
						win = true;
						break;
					}
					else if(tmpString2.equals(myString.trim())){
						oWins = true;
						win = true;
						break;
					}
				}//end inner for loop
			}//end outer else
		}//end check left and down

		return win;
	}//end check win method
	//check for a draw game	
	public static boolean checkDraw(String[][] brd){
		//now check for a tie game
		for(int i = 0; i < 10; i++){
			for(int j = 0; j < 10; j++){
				if(brd[i][j] != "`" || xWins != true || oWins != true){
					draw = true;
				}
				else{
					draw = false;
				} 
			}	
		}
		return draw;
	} 
	//Print the selected saved board state	
	public static void printBoard(String brd){
		String nb = brd.replace("[", "");
		String nb2 = nb.replace("]", "");
		String nb3 = nb2.replace(",", "");

		int wordsPerLine = 10;
		System.out.println("Here is the current board: ");
		int count = 1;
		for (int i = 0; i < nb3.length(); i++)
		{
			if (nb3.charAt(i) == ' ' && (count++) % wordsPerLine == 0)
				System.out.println();               
			else 
				System.out.print(nb3.charAt(i));
		}
		System.out.println();
	}
	//Scan the board in the right direction
	public static String scanR(int r, int c, int len, String m, String[][] brd){
		//clear the string
		m = " ";

		//if length is more than array size return 0
		if((len + c) > 10){
			System.out.println("error scanR: (len+c)>10");
		}
		//else run through rows and find string of x's or o's
		else{
			for(int i = 0; i < len; i++){
				m += brd[r][c];
				//System.out.println("r is " + r + " c is " + c);
				c++;
			}

		}
		//System.out.println("The string inside scanR is " + m);
		//System.out.println("The string reversed is " + reverseString(m));
		//System.out.println(m);
		return m;	
	}//end ScanR
	//scan the board in the right down direction
	public static String scanRD(int r, int c, int len, String m, String[][] brd){
		//clear the string
		m = " ";
		//if row and column is more than 5, you will overflow, then return 0
		if(r > 5 || c > 5){
			System.out.println("error scanRD: r>5 or c>5");
		}
		//else run through diagonally and find string of x's or o's
		else{
			for(int i = 0; i < len;){
				//System.out.println("i is " + i);
				for(int j = 0; j < len; j++){
					//System.out.println("r is " + r + " c is " + c);
					m += brd[r][c];
					r++;
					c++;
				}break;
			}			
		}
		//System.out.println("The string inside scanRD is " + m);
		//System.out.println("The string reversed is " + reverseString(m));
		return m;
	}//end ScanRD
	//scan the board in the down direction
	public static String scanD(int r, int c, int len, String m, String[][] brd){
		//clear the string
		m = " ";
		//System.out.println(len);
		//if length is more than array size return 0
		if((len + r) > 10){
			System.out.println("error scanD: (len+r)>10");
		}
		//else run through columns and find string of x's or o's
		else{
			for(int i = 0; i < len; i++){
				m += brd[r][c];
				//System.out.println("r is " + r + " c is " + c);
				r++;

			}			
		}
		//System.out.println("The string inside scanD is " + m);
		//System.out.println("The string reversed is " + reverseString(m));
		return m;
	}//end ScanD
	//scan in the left down direction
	public static String scanLD(int r, int c, int len, String m, String[][] brd){
		m = " ";
		int j = c;
		int count = (j - len);
		if(c < 3 || r > 7){
			System.out.println("error scanLD: r>6 or c<4");

		}
		//else run through diagonally and find string of x's or o's
		else{
			for(int i = r; i <= len; i++){
				// System.out.println("i is " + i);
				for(j = c; j > count; j--) {
					//System.out.println("r is " + r + " c is " + c);

					m += brd[r][c];
					r++;
					c--;
				}
			}			
		}

		//System.out.println("The string inside scanLD is " + m);
		//System.out.println("The string reversed is " + reverseString(m));
		return m;
	}//end ScanLD
	//Clear the board	
	public static void clearBoard(String[][] board){
		for(int r = 0; r < board.length; r++){
			for(int c = 0; c < board[r].length; c++){
				board[r][c] = "`";
			}
		}
	}
	//Reverse the string
	public static String reverseString(String m){
		int i, len = m.length();
		StringBuilder dest = new StringBuilder(len);

		for (i = (len - 1); i >= 0; i--){
			dest.append(m.charAt(i));
		}
		return dest.toString();
	}//end revereString
	//fill the board randomly
	public static void fillBoard(String[][] brd){
		for(int i = 0; i < brd.length; i++){
			for(int j = 0; j < brd.length; j++){
				Random rand = new Random();

				int  n = rand.nextInt(1000) + 1;
				if(n % 2 == 0){
					brd[i][j] = "X";
				}
				else{
					brd[i][j] = "O";
				}
			}
		}
	}
	//puts the board back into a 2D array after getting it from Board.java	
	public static String[][] twoDm(String s){
		String[][] tmpBrd = new String[10][10]; 
		String nb = s.replace("[", "");
		String nb2 = nb.replace("]", "");
		String nb3 = nb2.replace(",", "");
		Scanner sc = new Scanner(nb3);

		for (int r = 0; r < 10; r++) {
			for (int c = 0; c < 10; c++) {
				tmpBrd[r][c] = sc.next();
			}
		}
		sc.close();
		return tmpBrd;		
	}
	//Flip board horizontally	
	public static String[][] flipX(String[][] brd){
		String[][]horizontalImage = new String[10][10];
		for (int i = 0; i < 10; i++)
		{ 
			for(int j = 0; j < 10; j++)
			{  
				horizontalImage[10 - (i+1)][j] = brd[i][j];           
				horizontalImage[i][j] = brd[10 - (i+1)][j];		           
			}
		}   		   
		return horizontalImage;		
	}		
	//Flip board horizontally	
	public static String[][] flipY(String[][] brd){
		String[][] verticalImage = new String[10][10];
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 10; j++) {
				verticalImage[i][10 - j - 1] = brd[i][j];
			}
		}		    
		return verticalImage;
	}	
	//Flip board both horizontally and vertically
	public static String[][] flipBoth(String[][] brd) {
		String[][] flipped = flipX(brd);
		String[][] finalFlipped = flipY(flipped);
		return finalFlipped;
	}
	//clear the ArrayList
	public static void clearWeightsList(List<Double> doublesList){
		for(int i = 0; i < doublesList.size(); i++){
			doublesList.clear();
		}
	}
	//get best value from vHat	
}//end class