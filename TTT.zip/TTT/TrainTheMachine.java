import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;


public class TrainTheMachine{


	//constructor to hold individual training examples

	static ArrayList<String> set1;
	static ArrayList<String> set2;
	static int numVars1 = 0;
	static int numVars2 = 0;

	//ArrayLists to hold player 1 and player 2 weights
	static ArrayList<Double> p1Whts = new ArrayList<Double>();
	static ArrayList<Double> p2Whts = new ArrayList<Double>();
	static ArrayList<Double> newWhts = new ArrayList<Double>();
	static double startTarget = 100;
	static double rate = 2.0;
	static double extraW = 0.0;
	//read in file if no arg was given
	static String filein = "trainingFile.txt";
	//arrayList to hold reading from file
	static ArrayList<String> fileVal = new ArrayList<String>();
	//starting value for training examples  
	int startVal = 0;
	//ArrayLists to temp training examples
	static ArrayList<String> trainExample = new ArrayList<String>();
	
	static String wgtsOutFileName;

	public static void main(String[] args) {

		//read the name of the file into args
		if (args.length == 0 || args.length > 1) {
			System.out.println("args < 1 or args > 1.");
			//System.exit(-1);
		}
		else {
			for (String a : args) {
				filein = args[0];
				System.out.println("The name of the file path was " + a);
			}
		}		
		//try to read the file or throw exception	
		BufferedReader in = null;

		try {   
			in = new BufferedReader(new FileReader(filein));
			String str = " ";
			while ((str = in.readLine()) != null) {
				//need to split incoming string because training files are 
				//in two files
				if(str.contains(" "))
				{
					String[]  parts = str.split(" ");
					for(int i = 0; i < parts.length; i++){
						fileVal.add(parts[i]);
					}	
				}
				else{ 
					fileVal.add(str);
				}
			}					
		} catch (FileNotFoundException e) {
			System.out.println("File_Not_Found_Exception");					
		} catch (IOException e) {
			System.out.println("I/O_Exception");					
		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
					System.out.println("Close_File_Exception");							
				}
			}
		}
		for(int i = 0; i < fileVal.size(); i ++){
			System.out.println(fileVal.get(i));

		}

		//put all the contents from file into seperate variables
		String wgtsInFileName = fileVal.get(0),
				trainInfoFileName1 = fileVal.get(2), trainInfoFileName2 = fileVal.get(3),
				traceFileName = fileVal.get(4);
				
		wgtsOutFileName = fileVal.get(1);
		
		double aet = Double.parseDouble(fileVal.get(5));
		int maxit = Integer.parseInt(fileVal.get(6));


		//try to open the trace file or throw exception and quit	
		File fileout = new File(traceFileName);	
		try {
			fileout.createNewFile();				
		} catch (IOException e) {
			System.out.println("could not create file for output");
			System.exit(-1);				
		}

		//try to read the weights for each player or throw exception and quit	
		//clear the BufferedReader
		in = null;
		//temp arrayList for weights
		ArrayList<String> temp = new ArrayList<String>();
		try {   
			in = new BufferedReader(new FileReader(wgtsInFileName));
			String tmpStr = " ";
			//int i = 0;
			while ((tmpStr = in.readLine()) != null) {
				temp.add(tmpStr);
				//System.out.println("size is " + temp.size());
				//System.out.println("weights are " + temp.get(i));
				//i++;
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}		
		//add the weights to p1
		int end = (int)Double.parseDouble((temp.get(0)));
		for(int i = 1; i <= end; i++){
			p1Whts.add(Double.parseDouble(temp.get(i)));

		}
		//add the weights to p2
		int start = (end + 1);
		for(int i = start; i < temp.size(); i++){
			p2Whts.add(Double.parseDouble(temp.get(i)));
		}

		//try to read trainInfoFileName1 into set1 or throw exception and quit	
		//clear the BufferedReader
		in = null;
		//arrayList for player 1 training data 
		set1 = new ArrayList<String>();
		try {   
			in = new BufferedReader(new FileReader(trainInfoFileName1));
			String tmpStr = " ";
			//int i = 0;
			while ((tmpStr = in.readLine()) != null) {
				set1.add(tmpStr);
				//System.out.println("size is " + temp.size());
				//System.out.println("weights are " + temp.get(i));
				//i++;
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		//try to read trainInfoFileName1 into set1 or throw exception and quit	
		//clear the BufferedReader
		in = null;
		//arrayList for player 1 training data 
		set2 = new ArrayList<String>();
		try {   
			in = new BufferedReader(new FileReader(trainInfoFileName2));
			String tmpStr = " ";
			//int i = 0;
			while ((tmpStr = in.readLine()) != null) {
				set2.add(tmpStr);
				//System.out.println("size is " + temp.size());
				//System.out.println("weights are " + temp.get(i));
				//i++;
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}		

		//print set1 and set2
		//System.out.println(set1.size());
		for(int i = 0; i < set1.size(); i++){
			//System.out.println(set1.get(i));
		}

		for(int i = 0; i < set2.size(); i++){
			//System.out.println(set2.get(i));
		}
		//readTrainingSets(in, set1, end);
		//read a set then get value from vHat
		double vHatValue = readSet(p1Whts, set1, newWhts);
		double vHatValue2 = readSet(p2Whts, set2, newWhts);
		
	}
	
	public static double readSet(ArrayList<Double> Whts, ArrayList<String> varVals, ArrayList<Double> newWhts){
		int owner1 = 0, owner2 = 0, rslt = -1; //owners and the result of each set
		String end = "@"; //end of each set
		int counter = 0; //to stop the loop when the sets are done
		int setCounter = 0; //to count the number of sets
		ArrayList<String> temp1= new ArrayList<String>();
		ArrayList<Double> temp2= new ArrayList<Double>();
		double value = 0; //value returned from vHat
		//count the number of sets in VarVals
		for(int i = 0; i < varVals.size(); i++){
			if(varVals.get(i).equals(end)){
				setCounter++;
				//System.out.println("setCounter is " + setCounter);
			}
		}		
		do{
			int i = 0;
			while(!(varVals.get(i).equals(end))){

				String blank = varVals.get(i);
				//System.out.println("blank is " + blank);
				if(blank != null && !blank.isEmpty()){
					//System.out.println("Blank line not found");
				}
				else{
					String[] parts = varVals.get(i+1).split(" ");
					temp1.add(parts[0]); 
					temp1.add(parts[1]);
					
					if(Integer.parseInt(temp1.get(i)) == 1){
						owner1 = Integer.parseInt(temp1.get(0));
						//System.out.println("owner1 is " + owner1);
					}
					else{ 
						owner2 = Integer.parseInt(temp1.get(0));
						//System.out.println("owner2 is " + owner2);			
					}
					rslt = Integer.parseInt(temp1.get(1));
					//System.out.println("rslt is " + rslt);

					String[] pieces = varVals.get(2).split(" ");

					for(int j = 1; j < pieces.length; j++)
					{	
						//System.out.println("pieces is " + pieces[j]);
						temp2.add(Double.parseDouble(pieces[j]));
					}
					/*for(int j = 0; j < temp2.size(); j++){	
						System.out.println("temp is " + temp2.get(j));

					}*/
					//System.out.println("temp size is " + temp2.size());
					//System.out.println("Whts size is " + Whts.size());
				}				
				i++;		
			}
			value = newWeights(Whts, temp2, newWhts, startTarget, rate, extraW);
			System.out.println("value is " + value);
			counter++;
			//System.out.println("Counter is " + counter);
		}while(counter == setCounter);
		return value;
	}

	//send processed line to vHat
	public static double vHat(ArrayList<Double> Whts, ArrayList<Double> x, double extraWeight){
		double rval = 0.0;

		if (Whts.size() != x.size()){
			System.out.println("Weight: " + Whts.size() + " and X Vectors: " + x.size());
			System.out.println("vHat: weight & x vectors are different sizes");
			System.exit(0);
		}
		for (int i = 0; i < Whts.size(); i++){
			rval += Whts.get(i) * x.get(i);
		}	
		
		rval += extraWeight;

		return rval;
	}


	public static double newWght(double wght, double x, double rate, double errTerm)
	{
		return wght + (x * rate * errTerm);
	}

	//figure new weights and return error term
	public static double newWeights(ArrayList<Double> Whts, ArrayList<Double> vals, ArrayList<Double> newWeights, double target, double rate, double extraW){
		double errorTerm = 0.0,
				tmpw;
				
		File fout = new File(wgtsOutFileName);
		
		if (Whts.size() != vals.size()) {
			System.out.println("Weight: " + Whts.size() + " and Vals: " + vals.size());
			System.out.println("newWeights: weight & x vectors are different sizes");
		}

		//*** MAKE SURE nw IS EMPTY
		newWeights.clear();

		//errorTerm is returned from vHat
		errorTerm = target - vHat(Whts, vals, extraW);
		double sqdError = Math.sqrt(errorTerm);

		//Calculate the new weights and put them into ArrayList
		for (int i = 0; i < Whts.size(); i++)
		{
			tmpw = newWght(Whts.get(i), vals.get(i), rate, errorTerm);
			newWeights.add(tmpw);
		}
		
		for(int i = 0; i < Whts.size(); i++){
			//System.out.println("Old Weights" + Whts.get(i));
		}
		
		for(int i = 0; i < newWeights.size(); i++){
			//System.out.println("New Weights" + newWeights.get(i));
		}
 		
 		try {
 			BufferedWriter out = new BufferedWriter(new FileWriter(fout));
 			
			for (int i = 0; i < newWeights.size(); i++) {
				out.write(Double.toString(newWeights.get(i)));
				out.newLine();
			}
 			try {
			out.close();
			} catch (IOException e) {
				System.out.println("Could not close the new weights output file.");	
			}
		} catch (IOException e) {
			System.out.println("Could not write new weights.");				
		}
		
		System.out.println("Error term is " + sqdError);

		return sqdError;
	}

}



