import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;


public class compVsComp extends TicTacToe{	
	static ArrayList<Double> varVals = new ArrayList<Double>(10);
	static ArrayList<Double> p1Vals = new ArrayList<Double>(10);
	static ArrayList<Double> p2Vals = new ArrayList<Double>(10);
	public static void main(String[] args){
		//create an object to save each board after a player moves
		Board savedState = new Board();
		String[][] brd = new String [10][10];
		Scanner scanner = new Scanner(System.in);
		//ArrayLists to hold player 1 and player 2 weights
		ArrayList<Double> p1Whts = new ArrayList<Double>();
		ArrayList<Double> p2Whts = new ArrayList<Double>();

		//make sure the board is cleared
		clearBoard(brd);

		char[] tokens = {'`', 'X', 'O'};
		boolean player1 = true, player2 = false;		
		//=====================================================================================================
		//file to write to if no arg was given
		File fileout1 = new File("player1.txt");
		File fileout2 = new File("player2.txt");

		//read in vHat file if no arg was given
		String filein = "defense.txt";

		if (args.length == 0) {
			System.out.println("no arguments were given.");
		}
		else {
			for (String a : args) {
				filein = args[0];
				//create a new file if you want to	
				fileout1 = new File(args[1]);
				fileout2 = new File(args[2]);
				try {
					fileout1.createNewFile();
					fileout2.createNewFile();
				} catch (IOException e) {
					System.out.println("could not create file for output");
					e.printStackTrace();
				}

				System.out.println(a);
			}
		}
		//try to read the file or throw exception	
		BufferedReader in = null;
		ArrayList<String> temp = new ArrayList<String>();
		try {   
			in = new BufferedReader(new FileReader(filein));
			String str;
			while ((str = in.readLine()) != null) {
				temp.add(str);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}		


		//add the weights to p1
		int end = (int)Double.parseDouble((temp.get(0)));
		for(int i = 1; i <= end; i++){
			p1Whts.add(Double.parseDouble(temp.get(i)));
		}
		//add the weights to p2
		int start = (end + 1);
		for(int i = start; i < temp.size(); i++){
			p2Whts.add(Double.parseDouble(temp.get(i)));
		}


		//================================================================================================================
		//	Menu

		// handle user commands 
		boolean quit = false; 
		int menuItem; 
		do { 
			// print menu 
			String[] menu = {"Human vs. Human","Computer (Player 1) vs. Human (Player 2)",
					"Human (Player 1) vs. Computer (Player 2)", "Computer vs. Computer"};
			for (int i = 0; i <= menu.length -1; i++) 
				System.out.println((i + 1) + " " + menu[i]); 
			System.out.println("0. Quit"); 
			System.out.print("Choose menu item: "); 
			menuItem = scanner.nextInt(); 
			switch (menuItem) { 
			case 1:
				xWins = false; oWins = false; draw = false;
				//make sure the board is cleared
				clearBoard(brd);
				System.out.println("You've chosen item #1"); 
				System.out.println();

				//loop until game is won/lost/draw
				do {
					//prompt user for an X or an O
					do{	
						System.out.println("What would you like to mark: X or O?");
						String input = scanner.next();
						mark = input.toUpperCase();
						if(mark.equalsIgnoreCase("X") || mark.equalsIgnoreCase("O")){
							break;
						}
						else{
							System.out.println("Your mark must be an X or an O");
							System.out.println("Error on: " + mark);
							System.out.println();
						}

					}while((!mark.equalsIgnoreCase("X")) && !mark.equalsIgnoreCase("O"));				
					do {			
						//Prompt user for row 
						do{
							System.out.println("What row would you like to mark: [0 --> 9]");
							r = scanner.nextInt();
							if(r < 0 || r > 9){
								System.out.println("Your ROW must be between [0 --> 9]");
								System.out.println();
							}
						}while(r < 0 || r > 9);	

						//prompt user for column
						do{
							System.out.println("What column would you like to mark: [0 --> 9]");
							c = scanner.nextInt();
							if(c < 0 || c > 9){
								System.out.println("Your COLUMN must be between [0 --> 9]");
								System.out.println();
							}
						}while(c < 0 || c > 9);

						if(brd[r][c].equalsIgnoreCase("X") ||  brd[r][c].equalsIgnoreCase("O")) {
							System.out.println("Error: There is already a marker at [" + r + "]" + "[" + c + "]");
							System.out.println();					
						}
						else {
							brd[r][c] = mark;
						}
					}while(brd[r][c] == "X" ||  brd[r][c] == "O" );


					//get the saved state
					printBoard(brd);

				}while(checkWin(brd) == false || checkDraw(brd) == false);

				if(xWins == true){
					System.out.println("X wins the game");
					System.out.println();
				}
				else if(oWins == true){
					System.out.println("O wins the game");
					System.out.println();
				}
				else if(checkDraw(brd) == true){
					System.out.println("Its a draw!");
				}			
				break; 
			case 2: 
				xWins = false; oWins = false; draw = false;
				//make sure the board is cleared
				clearBoard(brd);							
				//loop until win or draw	
				do {					
					//computers turn==============================================	
					do{	
						System.out.println("computers turn and it marks an " + tokens[1] + " here:");				
						makeMove(brd, p1Whts, tokens, 1);	
						player1 = false;
						player2 = true;
					}while(player1 == true);

					//print the current board
					printBoard(brd);
					do{
						if(checkWin(brd)){
							break;
						}
						//players turn====================================================================
						do {			
							//Prompt user for row 
							do{
								System.out.println("What row would you like to mark: [0 --> 9]");
								r = scanner.nextInt();
								if(r < 0 || r > 9){
									System.out.println("Your ROW must be between [0 --> 9]");
									System.out.println();
								}
							}while(r < 0 || r > 9);	

							//prompt user for column
							do{
								System.out.println("What column would you like to mark: [0 --> 9]");
								c = scanner.nextInt();
								if(c < 0 || c > 9){
									System.out.println("Your COLUMN must be between [0 --> 9]");
									System.out.println();
								}
							}while(c < 0 || c > 9);

							if(brd[r][c].equalsIgnoreCase("X") ||  brd[r][c].equalsIgnoreCase("O")) {
								System.out.println("Error: There is already a marker at [" + r + "]" + "[" + c + "]");
								System.out.println();					
							}
							else {								
								brd[r][c] = String.valueOf(tokens[2]);
								player2 = false;
								player1 = true;								
							}								
						}while(brd[r][c] == "X" ||  brd[r][c] == "O" );							
						//print board
						printBoard(brd);
					}while(player2 == true);
				}while(checkWin(brd) == false || checkDraw(brd) == false);
				if(xWins == true){
					System.out.println(CompWinSaying());
					System.out.println();
				}
				else if(oWins == true){
					System.out.println(HumanWinSaying());
					System.out.println();
				}
				else if(checkDraw(brd) == true){
					System.out.println("Its a draw!");
				}			
				break; 

			case 3: 
				xWins = false; oWins = false; draw = false;
				//make sure the board is cleared
				clearBoard(brd);
				System.out.println("You've chosen item #3");
				System.out.println();
				do {	
					do{
						//players turn====================================================================
						do {			
							//Prompt user for row 
							do{
								System.out.println("What row would you like to mark: [0 --> 9]");
								r = scanner.nextInt();
								if(r < 0 || r > 9){
									System.out.println("Your ROW must be between [0 --> 9]");
									System.out.println();
								}
							}while(r < 0 || r > 9);	

							//prompt user for column
							do{
								System.out.println("What column would you like to mark: [0 --> 9]");
								c = scanner.nextInt();
								if(c < 0 || c > 9){
									System.out.println("Your COLUMN must be between [0 --> 9]");
									System.out.println();
								}
							}while(c < 0 || c > 9);

							if(brd[r][c].equalsIgnoreCase("X") ||  brd[r][c].equalsIgnoreCase("O")) {
								System.out.println("Error: There is already a marker at [" + r + "]" + "[" + c + "]");
								System.out.println();					
							}
							else {
								brd[r][c] = String.valueOf(tokens[1]);
								player2 = false;
								player1 = true;
							}
						}while(brd[r][c] == "X" ||  brd[r][c] == "O" );

						//print board
						printBoard(brd);
					}while(player2 == true);
					if(checkWin(brd)){
						//System.out.println(checkWin(brd));
						break;
					}
					do{	
						//computers turn==============================================	
						System.out.println("computers turn and it marks an " + tokens[2] + " here:");				
						makeMove(brd, p2Whts, tokens, 2);	
						player1 = false;
						player2 = true;
					}while(player1 == true);
					//print the current board
					printBoard(brd);
				}while(checkWin(brd) == false || checkDraw(brd) == false);

				if(xWins == true){
					System.out.println(HumanWinSaying());
					System.out.println();
				}
				else if(oWins == true){
					System.out.println(CompWinSaying());
					System.out.println();
				}
				else if(checkDraw(brd) == true){
					System.out.println("Its a draw!");
				}			
				break; 
			case 4:
				//create a writer object & initialize the BufferedWriter	
				BufferedWriter writer1 = null;	
				BufferedWriter writer2 = null;	
				//count the number of boards in saved state
				int brdCounter = 0;
				//variable to alternate turns
				boolean comp1 = true, comp2 = false;
				//reset wins and draws
				xWins = false; oWins = false; draw = false;
				//int variable that holds the result of the game
				int result = -1;
				int move = brdCounter;

				//make sure the board is cleared
				clearBoard(brd);
				System.out.println("You've chosen item #4");
				System.out.println();
				do {
					do{
						//computer1 to make a move
						makeMove(brd, p1Whts, tokens, 1);
						//save the board
						savedState.setBoardState(brdCounter, brd);
						getVals(brd, p1Vals, tokens[0], tokens[1], tokens[2]);
						/*for(int i = 0; i < p1Vals.size(); i++){
						System.out.println(p1Vals.get(i));
						}*/
						//increment the move number
						move++;
						System.out.println("move number " + move);						
						//print the current board to the screen
						printBoard(savedState.getSaveState(brdCounter));
						comp1 = false;
						comp2 = true;
						//increment the board number
						brdCounter++;

					}while(comp1 == true);
					if(checkWin(brd)){
						//System.out.println(checkWin(brd));
						break;
					}
					do{
						//increment the move number
						move++;
						//computer2 to make a move
						makeMove(brd, p2Whts, tokens, 2);
						//save the board
						savedState.setBoardState(brdCounter, brd);
						
						getVals(brd, p2Vals, tokens[0], tokens[1], tokens[2]);
						/*for(int i = 0; i < p2Vals.size(); i++){
						System.out.println(p2Vals.get(i));
						}*/
						System.out.println("move number " + move);
						//print the current board to the screen
						printBoard(savedState.getSaveState(brdCounter));
						comp2 = false;
						comp1 = true;
						//increment the board number
						brdCounter++;

					}while(comp2 == true);
				}while(checkWin(brd) == false || checkDraw(brd) == false);
				if(xWins == true){
					result = 1;
					System.out.println("Computer 1 wins");
					System.out.println(CompWinSaying());
					System.out.println();
				}
				else if(oWins == true){
					result = 2;
					System.out.println("Computer 2 wins");
					System.out.println(CompWinSaying());
					System.out.println();
				}
				else if(checkDraw(brd) == true){
					result = 0;
					System.out.println("Its a draw!");
				}
				/* get cVHlist backwards and save half to p1 arrayList
				 * and other half to p2 arrayList
				 * (its counting down), then write each to file on 
				 * one line */
				//System.out.println(varVals.size());
				for(int i = 0; i < p1Vals.size();i++){
					System.out.print(p1Vals.get(i) + " ");
						//writer.write(cVHlist.get(number) + " ");
					}
				System.out.println();
				for(int i = 0; i < p2Vals.size();i++){
						System.out.print(p2Vals.get(i) + " ");
						//writer.write(cVHlist.get(number) + " ");
					}						
					
					
				
				System.out.println();
				//write the boards in reverse order to the trace file
				//variable to count each time we write a board to the trace file
				int writeCounter = 0;
				//decrementer to count down boards
				int decrementer = brdCounter;


				//write to file
					try{	
						writer1 = new BufferedWriter(new FileWriter(fileout1, true));
						writer2 = new BufferedWriter(new FileWriter(fileout2, true));
						//writer.newLine();
						writer1.newLine();
						writer2.newLine();
						writer1.write("1 " + result);
						writer2.write("2 " + result);
						/* this says that the board belongs to the number of the computer
						 * (writeCounter counting up)*/						
						do{ 
						if(writeCounter % 2 == 0){
							writer1.newLine();
							for(int i = 0; i < p1Vals.size();i++) {
							  writer1.write(" " + Double.toString(p1Vals.get(i)));
							}
							writeCounter = 3;
						}
						if(writeCounter % 2 == 1){
							writer2.newLine();
							for(int i = 0; i < p2Vals.size();i++){
							  writer2.write(" " + Double.toString(p2Vals.get(i)));
							}
							writeCounter = 2;
						}
						  //decrement num until zero
						  decrementer--;
						}while(writeCounter != decrementer);
						
						writer1.newLine();
						writer2.newLine();
						//=====================================

						//======================================
						
						
						writer1.write("@");
						writer2.write("@");
						writer1.newLine();
						writer2.newLine();
						//clear the writer 
						writer1.flush();
						writer2.flush();	
					}

					catch(FileNotFoundException e)
					{
						System.out.println("File Not Found");
						System.exit( 1 );
					}
					catch(IOException e)
					{
						e.printStackTrace();
					}	
					writeCounter++;
					try {
						writer1.close();
						writer2.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
					//System.out.println("writeCounter is " + writeCounter);

				break; 
			case 0: 
				quit = true; 
				break; 
			default: 
				System.out.println("Invalid choice.");
				System.out.println();
			} 
		} while (!quit); 
		System.out.println("Bye-bye!"); 
		//end Menu
	}//end main
	//print the board
	public static void printBoard(String[][] b){

		System.out.println(" " + " 0 1 2 3 4 5 6 7 8 9");
		for(int r=0; r<b.length; r++) {
			System.out.print(r + " ");
			for(int c=0; c<b[r].length; c++)
				System.out.print(b[r][c] + " ");
			System.out.println();
		}
	}
	//computer to make a move
	public static void makeMove(String[][] brd, ArrayList<Double> wgts, char bVals[], int player){
		String blank = String.valueOf(bVals[0]), //*** CHARACTER REPRESENTING BLANK
				plChr = String.valueOf(bVals[player]); //*** CHARACTER REPRESENT CURRENT PLAYER
		int rMx = -1, //*** ROW OF BEST SQUARE SO FAR, -1 ALLOWS TEST FOR FIRST
				cMx = 0; //*** COLUMN OF BEST SQUARE SO FAR
		double vhMx = 0, //*** GREATEST VALUE OF VHAT SEEN SO FAR
			cVH; //*** vHat of current item
		

		//ArrayList<Double> varVals = new ArrayList<Double>(10);
		//*** FIND THE BEST SQUARE (ONE WITH HIGHEST VHAT VALUE)
		for (int r = 0; r < 10; r++)
			for (int c = 0; c < 10; c++)
				if (brd[r][c].equalsIgnoreCase(blank)) //*** WE'VE GOT ONE TO CHECK
				{
					brd[r][c] = plChr; //*** SUPPOSE WE MOVE HERE
					getVals(brd, varVals, bVals[0], bVals[1], bVals[2]);
					cVH = TrainTheMachine.vHat(varVals, wgts, 0);
					if ((rMx == -1) || (vhMx < cVH)) //*** WE HAVE A NEW MAX
					{
						rMx = r;
						cMx = c;
						vhMx = cVH;
					}
					brd[r][c] = blank; //*** SET CURRENT ONE BACK TO BLANK
				}
		if (rMx == -1) //*** NO BLANKS FOUND - JUST QUIT
			return;
		//*** OK, USE THE BEST ONE
		brd[rMx][cMx] = plChr;
	}

	//check the board for string patterns of 5
	public static void getVals(String [][] brd, ArrayList<Double> doublesList, char e, char p1, char p2){

		double oneXs = 0.0, twoXs = 0.0, threeXs = 0.0, fourXs = 0.0, fiveXs = 0.0, customXs = 0.0,
				oneOs = 0.0, twoOs = 0.0, threeOs = 0.0, fourOs = 0.0, fiveOs = 0.0, customOs = 0.0;

				//Strings of X's to check the board with
				String oneX = new StringBuilder().append(p1).append(e).append(e).append(e).append(e).toString();
				String twoX = new StringBuilder().append(p1).append(p1).append(e).append(e).append(e).toString();
				String threeX = new StringBuilder().append(p1).append(p1).append(p1).append(e).append(e).toString();
				String fourX = new StringBuilder().append(p1).append(p1).append(p1).append(p1).append(e).toString();
				String fiveX = new StringBuilder().append(p1).append(p1).append(p1).append(p1).append(p1).toString();

				//Strings of O's to check the board with		
				String oneO = new StringBuilder().append(p2).append(e).append(e).append(e).append(e).toString();
				String twoO = new StringBuilder().append(p2).append(p2).append(e).append(e).append(e).toString();
				String threeO = new StringBuilder().append(p2).append(p2).append(p2).append(e).append(e).toString();
				String fourO = new StringBuilder().append(p2).append(p2).append(p2).append(p2).append(e).toString();
				String fiveO = new StringBuilder().append(p2).append(p2).append(p2).append(p2).append(p2).toString();
				
				//Custom strings of four in a row with blank space on both ends
				String customX = new StringBuilder().append(e).append(p1).append(p1).append(p1).append(p1).append(e).toString();
				String customO = new StringBuilder().append(e).append(p2).append(p2).append(p2).append(p2).append(e).toString();

				clearWeightsList(doublesList);

				//SCAN RIGHT DIRECTION
				//check x's in the right direction for 1 X
				for(int i = 0; i < 10; i++){
					for(int j = 0; j < 6; j++){
						String myString = scanR(i, j, 5, oneX, brd);
						String revString = scanR(i, j, 5, oneX, flipY(brd));
						//System.out.println("myString is " + myString);
						if(oneX.equals(myString.trim()) || oneX.equals(new StringBuffer(myString).reverse().toString().trim())) {
							oneXs += 1.0;
						}
						if(oneX.equals(revString.trim()) || oneX.equals(new StringBuffer(revString).reverse().toString().trim())) {
							oneXs += 1.0;
						}
					}
				}

				//check x's in the right direction for 2 X's
				for(int i = 0; i < 10; i++){
					for(int j = 0; j < 6; j++){
						String myString = scanR(i, j, 5, twoX, brd);
						String revString = scanR(i, j, 5, oneX, flipY(brd));
						//System.out.println("myString is " + myString);
						if(twoX.equals(myString.trim()) || twoX.equals(new StringBuffer(myString).reverse().toString().trim())) {
							twoXs += 1.0;
						}
						if(twoX.equals(revString.trim()) || twoX.equals(new StringBuffer(revString).reverse().toString().trim())) {
							twoXs += 1.0;
						}
					}
				}

				//check x's in the right direction for 3 X's
				for(int i = 0; i < 10; i++){
					for(int j = 0; j < 6; j++){
						String myString = scanR(i, j, 5, threeX, brd);
						String revString = scanR(i, j, 5, threeX, flipY(brd));
						//System.out.println("myString is " + myString);
						if(threeX.equals(myString.trim()) || threeX.equals(new StringBuffer(myString).reverse().toString().trim())) {
							threeXs += 1.0;
						}
						if(threeX.equals(revString.trim()) || threeX.equals(new StringBuffer(revString).reverse().toString().trim())) {
							threeXs += 1.0;
						}
					}
				}

				//check x's in the right direction for 4 X's
				for(int i = 0; i < 10; i++){
					for(int j = 0; j < 6; j++){
						String myString = scanR(i, j, 5, fourX, brd);
						String revString = scanR(i, j, 5, fourX, flipY(brd));
						//System.out.println("myString is " + myString);
						if(fourX.equals(myString.trim()) || fourX.equals(new StringBuffer(myString).reverse().toString().trim())) {
							fourXs += 1.0;
						}
						if(fourX.equals(revString.trim()) || fourX.equals(new StringBuffer(revString).reverse().toString().trim())) {
							fourXs += 1.0;
						}
					}
				}

				//check x's in the right direction for 5 X's
				for(int i = 0; i < 10; i++){
					for(int j = 0; j < 6; j++){
						String myString = scanR(i, j, 5, fiveX, brd);
						String revString = scanR(i, j, 5, fiveX, flipY(brd));
						//System.out.println("myString is " + myString);
						if(fiveX.equals(myString.trim()) || fiveX.equals(new StringBuffer(myString).reverse().toString().trim())) {
							fiveXs += 1.0;
						}
						if(fiveX.equals(revString.trim()) || fiveX.equals(new StringBuffer(revString).reverse().toString().trim())) {
							fiveXs += 1.0;
						}				
					}
				}

				//check O's in the right direction for customO
				for(int i = 0; i < 10; i++){
					for(int j = 0; j < 5; j++){
						String myString = scanR(i, j, 6, customX, brd);
						String revString = scanR(i, j, 6, customX, flipY(brd));
						//System.out.println("myString is " + myString);
						if(customX.equals(myString.trim()) || customX.equals(new StringBuffer(myString).reverse().toString().trim())) {
							customXs += 1.0;
						}
						if(customX.equals(revString.trim()) || customX.equals(new StringBuffer(revString).reverse().toString().trim())) {
							customXs += 1.0;
						}				
					}
				}

				//SCAN RIGHT DOWN DIRECTION		
				//check x's in the right down direction for 1 X
				for(int i = 0; i < 6; i++){
					for(int j = 0; j < 6; j++){
						String myString = scanRD(i, j, 5, oneX, brd);
						String revString = scanRD(i, j, 5, oneX, flipBoth(brd));
						//System.out.println("myString is " + myString);
						if(oneX.equals(myString.trim()) || oneX.equals(new StringBuffer(myString).reverse().toString().trim())) {
							oneXs += 1.0;
						}
						if(oneX.equals(revString.trim()) || oneX.equals(new StringBuffer(revString).reverse().toString().trim())) {
							oneXs += 1.0;
						}
					}
				}

				//check x's in the right down direction for 2 X
				//int myStringCount = 0;
				//int myRevCount = 0;
				for(int i = 0; i < 6; i++){
					for(int j = 0; j < 6; j++){
						String myString = scanRD(i, j, 5, twoX, brd);
						String revString = scanRD(i, j, 5, twoX, flipBoth(brd));

						//System.out.println("revString is " + revString);
						//System.out.println("myString is " + myString);

						if(twoX.equals(myString.trim()) || twoX.equals(new StringBuffer(myString).reverse().toString().trim())) {
							twoXs += 1.0;
							//System.out.println("twoXs from myString is " + twoXs);
							//myStringCount++;
						}

						if(twoX.equals(revString.trim()) || twoX.equals(new StringBuffer(revString).reverse().toString().trim())) {
							twoXs += 1.0;
							//System.out.println("twoXs from revString is " + twoXs);
							//myRevCount++;
						}
					}
				}
				//System.out.println("MyStringCount is" + myStringCount);
				//System.out.println("MyRevCount is" + myRevCount);


				//check x's in the right down direction for 3 X
				for(int i = 0; i < 6; i++){
					for(int j = 0; j < 6; j++){
						String myString = scanRD(i, j, 5, threeX, brd);
						String revString = scanRD(i, j, 5, threeX, flipBoth(brd));
						//System.out.println("myString is " + myString);
						if(threeX.equals(myString.trim()) || threeX.equals(new StringBuffer(myString).reverse().toString().trim())) {
							threeXs += 1.0;
						}
						if(threeX.equals(revString.trim()) || threeX.equals(new StringBuffer(revString).reverse().toString().trim())) {
							threeXs += 1.0;
						}
					}
				}

				//check x's in the right down direction for 4 X
				for(int i = 0; i < 6; i++){
					for(int j = 0; j < 6; j++){
						String myString = scanRD(i, j, 5, fourX, brd);
						String revString = scanRD(i, j, 5, fourX, flipBoth(brd));
						//System.out.println("myString is " + myString);
						if(fourX.equals(myString.trim()) || fourX.equals(new StringBuffer(myString).reverse().toString().trim())) {
							fourXs += 1.0;
						}
						if(fourX.equals(revString.trim()) || fourX.equals(new StringBuffer(revString).reverse().toString().trim())) {
							fourXs += 1.0;
						}
					}
				}

				//check x's in the right down direction for 5 X
				for(int i = 0; i < 6; i++){
					for(int j = 0; j < 6; j++){
						String myString = scanRD(i, j, 5, fiveX, brd);
						String revString = scanRD(i, j, 5, fiveX, flipBoth(brd));
						//System.out.println("myString is " + myString);
						if(fiveX.equals(myString.trim()) || fiveX.equals(new StringBuffer(myString).reverse().toString().trim())) {
							fiveXs += 1.0;
						}
						if(fiveX.equals(revString.trim()) || fiveX.equals(new StringBuffer(revString).reverse().toString().trim())) {
							fiveXs += 1.0;
						}				
					}
				}

				//check O's in the right down direction for customO
				for(int i = 0; i < 5; i++){
					for(int j = 0; j < 5; j++){
						String myString = scanRD(i, j, 6, customX, brd);
						String revString = scanRD(i, j, 6, customX, flipBoth(brd));
						//System.out.println("myString is " + myString);
						if(customX.equals(myString.trim()) || customX.equals(new StringBuffer(myString).reverse().toString().trim())) {
							customXs += 1.0;
						}
						if(customX.equals(revString.trim()) || customX.equals(new StringBuffer(revString).reverse().toString().trim())) {
							customXs += 1.0;
						}				
					}
				}

				//SCAN DOWN DIRECTION
				//check x's in the down direction for 1 X
				for(int i = 0; i < 6; i++){
					for(int j = 0; j < 10; j++){
						String myString = scanD(i, j, 5, oneX, brd);
						String revString = scanD(i, j, 5, oneX, flipX(brd));
						//System.out.println("myString is " + myString);
						if(oneX.equals(myString.trim()) || oneX.equals(new StringBuffer(myString).reverse().toString().trim())) {
							oneXs += 1.0;
						}
						if(oneX.equals(revString.trim()) || oneX.equals(new StringBuffer(revString).reverse().toString().trim())) {
							oneXs += 1.0;
						}
					}
				}
				//check x's in the right direction for 2 X's
				for(int i = 0; i < 6; i++){
					for(int j = 0; j < 10; j++){
						String myString = scanD(i, j, 5, twoX, brd);
						String revString = scanD(i, j, 5, twoX, flipX(brd));
						//System.out.println("myString is " + myString);
						if(twoX.equals(myString.trim()) || twoX.equals(new StringBuffer(myString).reverse().toString().trim())) {
							twoXs += 1.0;
						}
						if(twoX.equals(revString.trim()) || twoX.equals(new StringBuffer(revString).reverse().toString().trim())) {
							twoXs += 1.0;
						}
					}
				}

				//check x's in the right direction for 3 X's
				for(int i = 0; i < 6; i++){
					for(int j = 0; j < 10; j++){
						String myString = scanD(i, j, 5, threeX, brd);
						String revString = scanD(i, j, 5, threeX, flipX(brd));
						//System.out.println("myString is " + myString);
						if(threeX.equals(myString.trim()) || threeX.equals(new StringBuffer(myString).reverse().toString().trim())) {
							threeXs += 1.0;
						}
						if(threeX.equals(revString.trim()) || threeX.equals(new StringBuffer(revString).reverse().toString().trim())) {
							threeXs += 1.0;
						}
					}
				}

				//check x's in the right direction for 4 X's
				for(int i = 0; i < 6; i++){
					for(int j = 0; j < 10; j++){
						String myString = scanD(i, j, 5, fourX, brd);
						String revString = scanD(i, j, 5, fourX, flipX(brd));
						//System.out.println("myString is " + myString);
						if(fourX.equals(myString.trim()) || fourX.equals(new StringBuffer(myString).reverse().toString().trim())) {
							fourXs += 1.0;
						}
						if(fourX.equals(revString.trim()) || fourX.equals(new StringBuffer(revString).reverse().toString().trim())) {
							fourXs += 1.0;
						}
					}
				}

				//check x's in the right direction for 5 X's
				for(int i = 0; i < 6; i++){
					for(int j = 0; j < 10; j++){
						String myString = scanD(i, j, 5, fiveX, brd);
						String revString = scanD(i, j, 5, fiveX, flipX(brd));
						//System.out.println("myString is " + myString);
						if(fiveX.equals(myString.trim()) || fiveX.equals(new StringBuffer(myString).reverse().toString().trim())) {
							fiveXs += 1.0;
						}
						if(fiveX.equals(revString.trim()) || fiveX.equals(new StringBuffer(revString).reverse().toString().trim())) {
							fiveXs += 1.0;
						}				
					}
				}

				//check O's in the down direction for customX
				for(int i = 0; i < 5; i++){
					for(int j = 0; j < 10; j++){
						String myString = scanD(i, j, 6, customX, brd);
						String revString = scanD(i, j, 6, customX, flipX(brd));
						//System.out.println("myString is " + myString);
						if(customX.equals(myString.trim()) || customX.equals(new StringBuffer(myString).reverse().toString().trim())) {
							customXs += 1.0;
						}
						if(customX.equals(revString.trim()) || customX.equals(new StringBuffer(revString).reverse().toString().trim())) {
							customXs += 1.0;
						}				
					}
				}

				//SCAN LEFT DOWN DIRECTION		
				//check x's in the left down direction for 1 X
				for(int i = 0; i < 6; i++){
					for(int j = 9; j > 3; j--){
						String myString = scanLD(i, j, 5, oneX, brd);
						String revString = scanLD(i, j, 5, oneX, flipBoth(brd));
						//System.out.println("myString is " + myString);
						if(oneX.equals(myString.trim()) || oneX.equals(new StringBuffer(myString).reverse().toString().trim())) {
							oneXs += 1.0;
						}
						if(oneX.equals(revString.trim()) || oneX.equals(new StringBuffer(revString).reverse().toString().trim())) {
							oneXs += 1.0;
						}
					}
				}

				//check x's in the left down direction for 2 X
				for(int i = 0; i < 6; i++){
					for(int j = 9; j > 3; j--){
						String myString = scanLD(i, j, 5, twoX, brd);
						String revString = scanLD(i, j, 5, twoX, flipBoth(brd));
						//System.out.println("myString is " + myString);
						if(twoX.equals(myString.trim()) || twoX.equals(new StringBuffer(myString).reverse().toString().trim())) {
							twoXs += 1.0;
						}
						if(twoX.equals(revString.trim()) || twoX.equals(new StringBuffer(revString).reverse().toString().trim())) {
							twoXs += 1.0;
						}
					}
				}

				//check x's in the left down direction for 3 X
				for(int i = 0; i < 6; i++){
					for(int j = 9; j > 3; j--){
						String myString = scanLD(i, j, 5, threeX, brd);
						String revString = scanLD(i, j, 5, threeX, flipBoth(brd));
						//System.out.println("myString is " + myString);
						if(threeX.equals(myString.trim()) || threeX.equals(new StringBuffer(myString).reverse().toString().trim())) {
							threeXs += 1.0;
						}
						if(threeX.equals(revString.trim()) || threeX.equals(new StringBuffer(revString).reverse().toString().trim())) {
							threeXs += 1.0;
						}
					}
				}

				//check x's in the left down direction for 4 X
				for(int i = 0; i < 6; i++){
					for(int j = 9; j > 3; j--){
						String myString = scanLD(i, j, 5, fourX, brd);
						String revString = scanLD(i, j, 5, fourX, flipBoth(brd));
						//System.out.println("myString is " + myString);
						if(fourX.equals(myString.trim()) || fourX.equals(new StringBuffer(myString).reverse().toString().trim())) {
							fourXs += 1.0;
						}
						if(fourX.equals(revString.trim()) || fourX.equals(new StringBuffer(revString).reverse().toString().trim())) {
							fourXs += 1.0;
						}
					}
				}

				//check x's in the left down direction for 5 X
				for(int i = 0; i < 6; i++){
					for(int j = 9; j > 3; j--){
						String myString = scanLD(i, j, 5, fiveX, brd);
						String revString = scanLD(i, j, 5, fiveX, flipBoth(brd));
						//System.out.println("myString is " + myString);
						if(fiveX.equals(myString.trim()) || fiveX.equals(new StringBuffer(myString).reverse().toString().trim())) {
							fiveXs += 1.0;
						}
						if(fiveX.equals(revString.trim()) || fiveX.equals(new StringBuffer(revString).reverse().toString().trim())) {
							fiveXs += 1.0;
						}				
					}
				}
				
				//check O's in the left down direction for customX
				for(int i = 0; i < 3; i++){
					for(int j = 9; j > 6; j--){
						String myString = scanLD(i, j, 6, customX, brd);
						String revString = scanLD(i, j, 6, customX, flipBoth(brd));
						//System.out.println("myString is " + myString);
						if(customX.equals(myString.trim()) || customX.equals(new StringBuffer(myString).reverse().toString().trim())) {
							customXs += 1.0;
						}
						if(customX.equals(revString.trim()) || customX.equals(new StringBuffer(revString).reverse().toString().trim())) {
							customXs += 1.0;
						}				
					}
				}

				//SCAN FOR O'S --------------------------------------------------------------------------
				//SCAN RIGHT DIRECTION
				//check O's in the right direction for 1 O
				for(int i = 0; i < 10; i++){
					for(int j = 0; j < 6; j++){
						String myString = scanR(i, j, 5, oneO, brd);
						String revString = scanR(i, j, 5, oneO, flipY(brd));
						//System.out.println("myString is " + myString);
						if(oneO.equals(myString.trim()) || oneO.equals(new StringBuffer(myString).reverse().toString().trim())) {
							oneOs += 1.0;
						}
						if(oneO.equals(revString.trim()) || oneO.equals(new StringBuffer(revString).reverse().toString().trim())) {
							oneOs += 1.0;
						}
					}
				}
				//check O's in the right direction for 2 O's
				for(int i = 0; i < 10; i++){
					for(int j = 0; j < 6; j++){
						String myString = scanR(i, j, 5, twoO, brd);
						String revString = scanR(i, j, 5, oneO, flipY(brd));
						//System.out.println("myString is " + myString);
						if(twoO.equals(myString.trim()) || twoO.equals(new StringBuffer(myString).reverse().toString().trim())) {
							twoOs += 1.0;
						}
						if(twoO.equals(revString.trim()) || twoO.equals(new StringBuffer(revString).reverse().toString().trim())) {
							twoOs += 1.0;
						}
					}
				}

				//check O's in the right direction for 3 O's
				for(int i = 0; i < 10; i++){
					for(int j = 0; j < 6; j++){
						String myString = scanR(i, j, 5, threeO, brd);
						String revString = scanR(i, j, 5, threeO, flipY(brd));
						//System.out.println("myString is " + myString);
						if(threeO.equals(myString.trim()) || threeO.equals(new StringBuffer(myString).reverse().toString().trim())) {
							threeOs += 1.0;
						}
						if(threeO.equals(revString.trim()) || threeO.equals(new StringBuffer(revString).reverse().toString().trim())) {
							threeOs += 1.0;
						}
					}
				}

				//check O's in the right direction for 4 O's
				for(int i = 0; i < 10; i++){
					for(int j = 0; j < 6; j++){
						String myString = scanR(i, j, 5, fourO, brd);
						String revString = scanR(i, j, 5, fourO, flipY(brd));
						//System.out.println("myString is " + myString);
						if(fourO.equals(myString.trim()) || fourO.equals(new StringBuffer(myString).reverse().toString().trim())) {
							fourOs += 1.0;
						}
						if(fourO.equals(revString.trim()) || fourO.equals(new StringBuffer(revString).reverse().toString().trim())) {
							fourOs += 1.0;
						}
					}
				}

				//check O's in the right direction for 5 O's
				for(int i = 0; i < 10; i++){
					for(int j = 0; j < 6; j++){
						String myString = scanR(i, j, 5, fiveO, brd);
						String revString = scanR(i, j, 5, fiveO, flipY(brd));
						//System.out.println("myString is " + myString);
						if(fiveO.equals(myString.trim()) || fiveO.equals(new StringBuffer(myString).reverse().toString().trim())) {
							fiveOs += 1.0;
						}
						if(fiveO.equals(revString.trim()) || fiveO.equals(new StringBuffer(revString).reverse().toString().trim())) {
							fiveOs += 1.0;
						}				
					}
				}

				//check O's in the right direction for customO
				for(int i = 0; i < 10; i++){
					for(int j = 0; j < 5; j++){
						String myString = scanR(i, j, 6, customO, brd);
						String revString = scanR(i, j, 6, customO, flipY(brd));
						//System.out.println("myString is " + myString);
						if(customO.equals(myString.trim()) || customO.equals(new StringBuffer(myString).reverse().toString().trim())) {
							customOs += 1.0;
						}
						if(customO.equals(revString.trim()) || customO.equals(new StringBuffer(revString).reverse().toString().trim())) {
							customOs += 1.0;
						}				
					}
				}

				//SCAN RIGHT DOWN DIRECTION		
				//check O's in the right down direction for 1 O
				for(int i = 0; i < 6; i++){
					for(int j = 0; j < 6; j++){
						String myString = scanRD(i, j, 5, oneO, brd);
						String revString = scanRD(i, j, 5, oneO, flipBoth(brd));
						//System.out.println("myString is " + myString);
						if(oneO.equals(myString.trim()) || oneO.equals(new StringBuffer(myString).reverse().toString().trim())) {
							oneOs += 1.0;
						}
						if(oneO.equals(revString.trim()) || oneO.equals(new StringBuffer(revString).reverse().toString().trim())) {
							oneOs += 1.0;
						}
					}
				}

				//check O's in the right down direction for 2 O's

				for(int i = 0; i < 6; i++){
					for(int j = 0; j < 6; j++){
						String myString = scanRD(i, j, 5, twoO, brd);
						String revString = scanRD(i, j, 5, twoO, flipBoth(brd));

						//System.out.println("revString is " + revString);
						//System.out.println("myString is " + myString);

						if(twoO.equals(myString.trim()) || twoO.equals(new StringBuffer(myString).reverse().toString().trim())) {
							twoOs += 1.0;

						}

						if(twoO.equals(revString.trim()) || twoO.equals(new StringBuffer(revString).reverse().toString().trim())) {
							twoOs += 1.0;

						}
					}
				}


				//check O's in the right down direction for 3 O's
				for(int i = 0; i < 6; i++){
					for(int j = 0; j < 6; j++){
						String myString = scanRD(i, j, 5, threeO, brd);
						String revString = scanRD(i, j, 5, threeO, flipBoth(brd));
						//System.out.println("myString is " + myString);
						if(threeO.equals(myString.trim()) || threeO.equals(new StringBuffer(myString).reverse().toString().trim())) {
							threeOs += 1.0;
						}
						if(threeO.equals(revString.trim()) || threeO.equals(new StringBuffer(revString).reverse().toString().trim())) {
							threeOs += 1.0;
						}
					}
				}

				//check O's in the right down direction for 4 O's
				for(int i = 0; i < 6; i++){
					for(int j = 0; j < 6; j++){
						String myString = scanRD(i, j, 5, fourO, brd);
						String revString = scanRD(i, j, 5, fourO, flipBoth(brd));
						//System.out.println("myString is " + myString);
						if(fourO.equals(myString.trim()) || fourO.equals(new StringBuffer(myString).reverse().toString().trim())) {
							fourOs += 1.0;
						}
						if(fourO.equals(revString.trim()) || fourO.equals(new StringBuffer(revString).reverse().toString().trim())) {
							fourOs += 1.0;
						}
					}
				}

				//check O's in the right down direction for 5 O's
				for(int i = 0; i < 6; i++){
					for(int j = 0; j < 6; j++){
						String myString = scanRD(i, j, 5, fiveO, brd);
						String revString = scanRD(i, j, 5, fiveO, flipBoth(brd));
						//System.out.println("myString is " + myString);
						if(fiveO.equals(myString.trim()) || fiveO.equals(new StringBuffer(myString).reverse().toString().trim())) {
							fiveOs += 1.0;
						}
						if(fiveO.equals(revString.trim()) || fiveO.equals(new StringBuffer(revString).reverse().toString().trim())) {
							fiveOs += 1.0;
						}				
					}
				}

				//check O's in the right down direction for customO
				for(int i = 0; i < 5; i++){
					for(int j = 0; j < 5; j++){
						String myString = scanRD(i, j, 6, customO, brd);
						String revString = scanRD(i, j, 6, customO, flipBoth(brd));
						//System.out.println("myString is " + myString);
						if(customO.equals(myString.trim()) || customO.equals(new StringBuffer(myString).reverse().toString().trim())) {
							customOs += 1.0;
						}
						if(customO.equals(revString.trim()) || customO.equals(new StringBuffer(revString).reverse().toString().trim())) {
							customOs += 1.0;
						}				
					}
				}

				//SCAN DOWN DIRECTION
				//check O's in the down direction for 1 O
				for(int i = 0; i < 6; i++){
					for(int j = 0; j < 10; j++){
						String myString = scanD(i, j, 5, oneO, brd);
						String revString = scanD(i, j, 5, oneO, flipX(brd));
						//System.out.println("myString is " + myString);
						if(oneO.equals(myString.trim()) || oneO.equals(new StringBuffer(myString).reverse().toString().trim())) {
							oneOs += 1.0;
						}
						if(oneO.equals(revString.trim()) || oneO.equals(new StringBuffer(revString).reverse().toString().trim())) {
							oneOs += 1.0;
						}
					}
				}
				//check O's in the down direction for 2 O's
				for(int i = 0; i < 6; i++){
					for(int j = 0; j < 10; j++){
						String myString = scanD(i, j, 5, twoO, brd);
						String revString = scanD(i, j, 5, twoO, flipX(brd));
						//System.out.println("myString is " + myString);
						if(twoO.equals(myString.trim()) || twoO.equals(new StringBuffer(myString).reverse().toString().trim())) {
							twoOs += 1.0;
						}
						if(twoO.equals(revString.trim()) || twoO.equals(new StringBuffer(revString).reverse().toString().trim())) {
							twoOs += 1.0;
						}
					}
				}

				//check O's in the down direction for 3 O's
				for(int i = 0; i < 6; i++){
					for(int j = 0; j < 10; j++){
						String myString = scanD(i, j, 5, threeO, brd);
						String revString = scanD(i, j, 5, threeO, flipX(brd));
						//System.out.println("myString is " + myString);
						if(threeO.equals(myString.trim()) || threeO.equals(new StringBuffer(myString).reverse().toString().trim())) {
							threeOs += 1.0;
						}
						if(threeO.equals(revString.trim()) || threeO.equals(new StringBuffer(revString).reverse().toString().trim())) {
							threeOs += 1.0;
						}
					}
				}

				//check O's in the down direction for 4 O's
				for(int i = 0; i < 6; i++){
					for(int j = 0; j < 10; j++){
						String myString = scanD(i, j, 5, fourO, brd);
						String revString = scanD(i, j, 5, fourO, flipX(brd));
						//System.out.println("myString is " + myString);
						if(fourO.equals(myString.trim()) || fourO.equals(new StringBuffer(myString).reverse().toString().trim())) {
							fourOs += 1.0;
						}
						if(fourO.equals(revString.trim()) || fourO.equals(new StringBuffer(revString).reverse().toString().trim())) {
							fourOs += 1.0;
						}
					}
				}

				//check O's in the down direction for 5 O's
				for(int i = 0; i < 6; i++){
					for(int j = 0; j < 10; j++){
						String myString = scanD(i, j, 5, fiveO, brd);
						String revString = scanD(i, j, 5, fiveO, flipX(brd));
						//System.out.println("myString is " + myString);
						if(fiveO.equals(myString.trim()) || fiveO.equals(new StringBuffer(myString).reverse().toString().trim())) {
							fiveOs += 1.0;
						}
						if(fiveO.equals(revString.trim()) || fiveO.equals(new StringBuffer(revString).reverse().toString().trim())) {
							fiveOs += 1.0;
						}				
					}
				}

				//check O's in the down direction for customO
				for(int i = 0; i < 5; i++){
					for(int j = 0; j < 10; j++){
						String myString = scanD(i, j, 6, customO, brd);
						String revString = scanD(i, j, 6, customO, flipX(brd));
						//System.out.println("myString is " + myString);
						if(customO.equals(myString.trim()) || customO.equals(new StringBuffer(myString).reverse().toString().trim())) {
							customOs += 1.0;
						}
						if(customO.equals(revString.trim()) || customO.equals(new StringBuffer(revString).reverse().toString().trim())) {
							customOs += 1.0;
						}				
					}
				}

				//SCAN LEFT DOWN DIRECTION		
				//check O's in the left down direction for 1 O
				for(int i = 0; i < 6; i++){
					for(int j = 9; j > 3; j--){
						String myString = scanLD(i, j, 5, oneO, brd);
						String revString = scanLD(i, j, 5, oneO, flipBoth(brd));
						//System.out.println("myString is " + myString);
						if(oneO.equals(myString.trim()) || oneO.equals(new StringBuffer(myString).reverse().toString().trim())) {
							oneOs += 1.0;
						}
						if(oneO.equals(revString.trim()) || oneO.equals(new StringBuffer(revString).reverse().toString().trim())) {
							oneOs += 1.0;
						}
					}
				}

				//check O's in the left down direction for 2 O
				for(int i = 0; i < 6; i++){
					for(int j = 9; j > 3; j--){
						String myString = scanLD(i, j, 5, twoO, brd);
						String revString = scanLD(i, j, 5, twoO, flipBoth(brd));
						//System.out.println("myString is " + myString);
						if(twoO.equals(myString.trim()) || twoO.equals(new StringBuffer(myString).reverse().toString().trim())) {
							twoOs += 1.0;
						}
						if(twoO.equals(revString.trim()) || twoO.equals(new StringBuffer(revString).reverse().toString().trim())) {
							twoOs += 1.0;
						}
					}
				}

				//check O's in the left down direction for 3 O
				for(int i = 0; i < 6; i++){
					for(int j = 9; j > 3; j--){
						String myString = scanLD(i, j, 5, threeO, brd);
						String revString = scanLD(i, j, 5, threeO, flipBoth(brd));
						//System.out.println("myString is " + myString);
						if(threeO.equals(myString.trim()) || threeO.equals(new StringBuffer(myString).reverse().toString().trim())) {
							threeOs += 1.0;
						}
						if(threeO.equals(revString.trim()) || threeO.equals(new StringBuffer(revString).reverse().toString().trim())) {
							threeOs += 1.0;
						}
					}
				}

				//check O's in the left down direction for 4 O
				for(int i = 0; i < 6; i++){
					for(int j = 9; j > 3; j--){
						String myString = scanLD(i, j, 5, fourO, brd);
						String revString = scanLD(i, j, 5, fourO, flipBoth(brd));
						//System.out.println("myString is " + myString);
						if(fourO.equals(myString.trim()) || fourO.equals(new StringBuffer(myString).reverse().toString().trim())) {
							fourOs += 1.0;
						}
						if(fourO.equals(revString.trim()) || fourO.equals(new StringBuffer(revString).reverse().toString().trim())) {
							fourOs += 1.0;
						}
					}
				}

				//check O's in the left down direction for 5 O
				for(int i = 0; i < 6; i++){
					for(int j = 9; j > 3; j--){
						String myString = scanLD(i, j, 5, fiveO, brd);
						String revString = scanLD(i, j, 5, fiveO, flipBoth(brd));
						//System.out.println("myString is " + myString);
						if(fiveO.equals(myString.trim()) || fiveO.equals(new StringBuffer(myString).reverse().toString().trim())) {
							fiveOs += 1.0;
						}
						if(fiveO.equals(revString.trim()) || fiveO.equals(new StringBuffer(revString).reverse().toString().trim())) {
							fiveOs += 1.0;
						}				
					}
				}
				
				//check O's in the left down direction for customO
				for(int i = 0; i < 3; i++){
					for(int j = 9; j > 6; j--){
						String myString = scanLD(i, j, 6, customO, brd);
						String revString = scanLD(i, j, 6, customO, flipBoth(brd));
						//System.out.println("myString is " + myString);
						if(customO.equals(myString.trim()) || customO.equals(new StringBuffer(myString).reverse().toString().trim())) {
							customOs += 1.0;
						}
						if(customO.equals(revString.trim()) || customO.equals(new StringBuffer(revString).reverse().toString().trim())) {
							customOs += 1.0;
						}				
					}
				}

				doublesList.add(0, oneXs);
				doublesList.add(1, twoXs);
				doublesList.add(2, threeXs);
				doublesList.add(3, fourXs);
				doublesList.add(4, fiveXs);
				doublesList.add(5, oneOs);
				doublesList.add(6, twoOs);
				doublesList.add(7, threeOs);
				doublesList.add(8, fourOs);
				doublesList.add(9, fiveOs);
				doublesList.add(10, customXs);
				doublesList.add(11, customOs);

				/*System.out.println(doublesList.get(0));
						System.out.println(doublesList.get(1));
						System.out.println(doublesList.get(2));
						System.out.println(doublesList.get(3));
						System.out.println(doublesList.get(4));
						System.out.println(doublesList.get(5));
						System.out.println(doublesList.get(6));
						System.out.println(doublesList.get(7));
						System.out.println(doublesList.get(8));
						System.out.println(doublesList.get(9));
				 */
	}//end getXvals	
	public static String CompWinSaying(){
		String[] saying = {"the dark side is always victorious, you lose", "puny human you can't defeat me, you lose", "your mistake was playing against me in the first place, you lose",
				"you should upgrade your processor if you want to beat me", "bada bing bada BOOM baby, better luck next time, you lose", "better hit the books if you want to defeat me, you lose",
				"did you mean to lose or was that your best?", "the door is on your left, you lose", "hahahah, too bad sooo sad, you lose", "congratulations to me, you lose"};
		//System.out.println(saying.length);
		Random rn = new Random();
		int answer = rn.nextInt(10);
		return saying[answer];		
	}
	public static String HumanWinSaying(){

		String[] saying = {"you win this time, but i will be victorious!!!", "you are too smart for me. you win mortal", "The force is strong with you, nice win earthling",
				"you got soooo lucky this time, you win", "awe snap, you win", "jimmy crack corn and I dont care, your a weiner", "winner, winner, chicken dinner, you win",
				"feelin` lucky hah punk, nice win", "dang it, i didn't mean to go there, you win", "congratulations human, my binary must be off a little, nice win"};
		Random rn = new Random();
		int answer = rn.nextInt(10);
		return saying[answer];		
	}
}//end compVsComp class
